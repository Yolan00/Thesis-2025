# Data

The data is from the human-human interactions released by the prior work “Continual Adaptation for Efficient Machine Communication”  https://github.com/hawkrobe/continual-adaptation/tree/main/writing



The dataset contains 54 human-human interactions on a subset of all the referential contexts provided by the prior work. Some referential contexts have more than one human-human interactions but the dataset is roughly balanced. Each interaction is saved in a folder. 

